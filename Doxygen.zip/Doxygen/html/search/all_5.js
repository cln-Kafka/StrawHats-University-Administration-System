var searchData=
[
  ['get_5fage_0',['get_age',['../class_person.html#ab9df2b4293818efe92ea9ebfb73550e6',1,'Person::get_age()'],['../class_professor.html#ae4b1f7b1ae24cca3cd7a42f51e2d89b2',1,'Professor::get_age()'],['../class_student.html#ad3f92036c7aa49b9a1b7731125db8aa7',1,'Student::get_age()']]],
  ['get_5fcode_1',['get_code',['../class_class.html#adc1a1597fe381867ae94a8ac2fa19634',1,'Class']]],
  ['get_5fconcatinated_5fname_2',['get_concatinated_name',['../class_professor.html#a58a0a6bd8b7068d5c50cc679bf0b9118',1,'Professor::get_concatinated_name()'],['../class_student.html#a653060ea37cb5436157ec87f582d9317',1,'Student::get_concatinated_name()']]],
  ['get_5femail_3',['get_email',['../class_person.html#aba67b07912fc6d305bfb093ca24f053b',1,'Person::get_email()'],['../class_professor.html#ab128960767303f43bb022c872101702f',1,'Professor::get_email()'],['../class_student.html#a74e089cfe6f00f04128f37edaa14d332',1,'Student::get_email()']]],
  ['get_5ffirst_5fname_4',['get_first_name',['../class_person.html#ab444f1a1f1dc165a380c8f429912ed17',1,'Person::get_first_name()'],['../class_professor.html#a0aa2d3657fb24255151088bb99527ab7',1,'Professor::get_first_name()'],['../class_student.html#a5efe512ae620d15abff05d4984524726',1,'Student::get_first_name()']]],
  ['get_5fgrade_5',['get_grade',['../class_student.html#ad86c516c4006f6b0415195e86de91f5f',1,'Student']]],
  ['get_5flast_5fname_6',['get_last_name',['../class_person.html#af29fac07de9de99d178870d70cf8841c',1,'Person::get_last_name()'],['../class_professor.html#af4d1ded9767d54e768681808ef33d9cf',1,'Professor::get_last_name()'],['../class_student.html#a55b68845ac9e859e3e7424db94753dba',1,'Student::get_last_name()']]],
  ['get_5flecture_5fhall_7',['get_lecture_hall',['../class_class.html#a8ce84a0a7a691fbfb631aa00d62edcd2',1,'Class']]],
  ['get_5fmobile_8',['get_mobile',['../class_person.html#ad35d0fe8ffa70cbf4212988db8aab4ae',1,'Person::get_mobile()'],['../class_professor.html#aef76e90a5094691c3150b4682687e24c',1,'Professor::get_mobile()'],['../class_student.html#a37c908802e5ccf2733b852c8af00ab17',1,'Student::get_mobile()']]],
  ['get_5fname_9',['get_name',['../class_class.html#aed2ff3be4d4e32a850cf0caed2ec94d6',1,'Class::get_name()'],['../class_hall.html#a288979c0690d508f0cd964666b5300bd',1,'Hall::get_name()']]],
  ['get_5fstart_5ftime_10',['get_start_time',['../class_class.html#a70faaf0561787ad11c8f6b1bb6524464',1,'Class']]],
  ['get_5ftitle_11',['get_title',['../class_professor.html#ada057c8ca5bbaf5932076e167425b843',1,'Professor']]]
];
