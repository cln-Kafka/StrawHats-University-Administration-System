var searchData=
[
  ['hall_0',['Hall',['../class_hall.html',1,'Hall'],['../class_hall.html#a5936f22ec8dea1e64e1d18f326520429',1,'Hall::Hall(QObject *parent=nullptr)'],['../class_hall.html#af7679ff2b0a155f6aa01865c344ca386',1,'Hall::Hall(const Hall &amp;another_hall)'],['../class_hall.html#a901ffa4f0b4001defeea8e7bee9c5c85',1,'Hall::Hall(QString name)']]],
  ['halls_1',['halls',['../class_dashboard.html#a2b53ba18f098c31553f2bc57def014c7',1,'Dashboard']]]
];
