var searchData=
[
  ['person_0',['Person',['../class_person.html',1,'Person'],['../class_person.html#afadaf16559a0a5c8f292705bc84d67b9',1,'Person::Person()']]],
  ['print_5fclass_5finformation_1',['print_class_information',['../class_class.html#a2252cb9b3b7da3476e47711b42d0fd83',1,'Class']]],
  ['print_5finformation_2',['print_information',['../class_person.html#a79ffd9f3d7ca5abe8eec91ee7c75edb1',1,'Person::print_information()'],['../class_professor.html#af46b81ea514dc75de72dd6bc26038aff',1,'Professor::print_information()']]],
  ['print_5fprofessors_3',['print_professors',['../class_class.html#a3a812665ff7590dd8c57fa456602c7c8',1,'Class']]],
  ['print_5fstudents_5fgrades_4',['Print_students_grades',['../class_class.html#af70b67b327fdc176b8ca79c3a69ce89d',1,'Class']]],
  ['print_5fstudents_5fnames_5',['Print_students_names',['../class_class.html#a2411312963d376813d4c339e8fc2442f',1,'Class']]],
  ['professor_6',['Professor',['../class_professor.html',1,'Professor'],['../class_professor.html#aa6e5358d66e4df08f83886781af86503',1,'Professor::Professor(Person *parent=nullptr)'],['../class_professor.html#abeb39a5c0668098d28925f37d781f097',1,'Professor::Professor(const Professor &amp;another_professor)'],['../class_professor.html#a7af18d6fec5e7ea9a9cc429bd6cb0c17',1,'Professor::Professor(QString first, QString second, QString age, QString email, QString mobile, QString title)']]],
  ['professors_7',['professors',['../class_dashboard.html#a49878ea23921aba3b7aa768bf641ef57',1,'Dashboard']]]
];
