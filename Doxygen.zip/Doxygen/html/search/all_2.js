var searchData=
[
  ['dashboard_0',['Dashboard',['../class_dashboard.html',1,'']]],
  ['delete_5fclass_1',['delete_class',['../class_hall.html#aff9519666cf215b783414d827a6be929',1,'Hall']]],
  ['delete_5fclass_5fprof_5fteaches_2',['delete_Class_prof_teaches',['../class_professor.html#aa2c8b8faef358da1f47f8ea607878a4d',1,'Professor']]],
  ['delete_5fenrolled_5fstudent_3',['delete_enrolled_student',['../class_class.html#a78ee5be25f1e5d17bd66b7387bfc4c7a',1,'Class']]],
  ['delete_5fprofessor_4',['delete_professor',['../class_class.html#a1439efbfe0faf6969fe6b3ea5bce6d1d',1,'Class']]]
];
