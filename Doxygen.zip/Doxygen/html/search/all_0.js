var searchData=
[
  ['add_5faclass_5fprof_5fteaches_0',['add_Aclass_prof_teaches',['../class_professor.html#ac7a031fe9d7cfc5bb18aca4966677d62',1,'Professor']]],
  ['add_5fclass_1',['add_class',['../class_hall.html#a316598af6617b30a2bccf1759fae4b66',1,'Hall']]],
  ['add_5fenrolled_5fstudent_2',['add_enrolled_student',['../class_class.html#a235b4e7237944934060ed3be78295af3',1,'Class']]],
  ['add_5fprofessor_3',['add_professor',['../class_class.html#a54131dcece606cfda25c15f6f8a586dd',1,'Class']]]
];
