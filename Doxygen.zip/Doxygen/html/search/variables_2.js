var searchData=
[
  ['professors_0',['professors',['../class_dashboard.html#a49878ea23921aba3b7aa768bf641ef57',1,'Dashboard']]]
];
