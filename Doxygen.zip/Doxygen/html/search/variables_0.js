var searchData=
[
  ['courses_0',['courses',['../class_dashboard.html#a39c8cd5b5dfa31a9e5a98b8a52d21215',1,'Dashboard']]]
];
