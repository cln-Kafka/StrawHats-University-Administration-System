var searchData=
[
  ['find_5faclass_5fprof_5fteaches_0',['find_Aclass_prof_teaches',['../class_professor.html#adc026ef4306fb1bb7f489b73ecd6f9a4',1,'Professor']]],
  ['find_5fenrolled_5fstudent_1',['find_enrolled_student',['../class_class.html#ab90e08261954962704059bc5f2444335',1,'Class']]]
];
