var searchData=
[
  ['search_5ffor_5fprofessor_0',['search_for_professor',['../class_class.html#aea921b2bc73de7b43082afa7dd2c9070',1,'Class']]],
  ['search_5ffor_5fstudent_1',['search_for_student',['../class_class.html#a390a0558064c67a1bca83b569be792cf',1,'Class']]],
  ['set_5fage_2',['set_age',['../class_person.html#ada8ae719e29aaa31ffd74c101319fc33',1,'Person::set_age()'],['../class_professor.html#a8a41f9d492ab994f96615b24cb0115cd',1,'Professor::set_age()'],['../class_student.html#add4cf3bafa5c2b2d0a908303e344f3f7',1,'Student::set_age()']]],
  ['set_5fcode_3',['set_code',['../class_class.html#aae034ee1e74c00966b4c594a2c380741',1,'Class']]],
  ['set_5femail_4',['set_email',['../class_person.html#a2ba2720c475c483e27f4652645ad5654',1,'Person::set_email()'],['../class_professor.html#aadedfec5670493299e13673d627544ab',1,'Professor::set_email()'],['../class_student.html#aac850509ea58d5cd8877d98c42d2e393',1,'Student::set_email()']]],
  ['set_5ffirst_5fname_5',['set_first_name',['../class_person.html#a7ad3e7c7304aca70bfc54906e85d86e4',1,'Person::set_first_name()'],['../class_professor.html#a1e194b6daccc87e1335fe08b6fd8f0ca',1,'Professor::set_first_name()'],['../class_student.html#aee7a3c3fb41028ed5bdd55995d572758',1,'Student::set_first_name(const QString &amp;)']]],
  ['set_5fgrade_6',['set_grade',['../class_student.html#af8f4393da43c32806301278d2cf8377f',1,'Student']]],
  ['set_5flast_5fname_7',['set_last_name',['../class_person.html#a85b1eafcf177ef4a4efd86b479135b82',1,'Person::set_last_name()'],['../class_professor.html#ad56d57e48c85fbeedff4de95079d91ce',1,'Professor::set_last_name()'],['../class_student.html#aa7e950485dbdb6b884ed981aaa107314',1,'Student::set_last_name()']]],
  ['set_5flecture_5fhall_8',['set_lecture_hall',['../class_class.html#a8fdcea3d740ffac60b1b2e8e2ba58dea',1,'Class']]],
  ['set_5fmobile_9',['set_mobile',['../class_person.html#a7d3b853529ca6db34dc3d8704c163178',1,'Person::set_mobile()'],['../class_professor.html#af90debed3a554a97a2ef1d74fbb2cf36',1,'Professor::set_mobile()'],['../class_student.html#a8fccdf24689da26383753e427e7a39ed',1,'Student::set_mobile()']]],
  ['set_5fname_10',['set_name',['../class_class.html#a1107498f55c7a0b3a0f696d531f0c47b',1,'Class::set_name()'],['../class_hall.html#a90b44ae5ce6eaf73ba21ea2562ff282d',1,'Hall::set_name()']]],
  ['set_5fstart_5ftime_11',['set_start_time',['../class_class.html#a18718cbb050194d74bba8f38aacb0382',1,'Class']]],
  ['set_5ftitle_12',['set_title',['../class_professor.html#a6b7ad3d5902ea1c0b01f7cb9c5b4e0c3',1,'Professor']]],
  ['student_13',['Student',['../class_student.html',1,'Student'],['../class_student.html#aafdbac042026ba00a7ecff204dd80e7a',1,'Student::Student(Person *parent=nullptr)'],['../class_student.html#ad6f4295fd65821408b4897e6559e07ab',1,'Student::Student(const Student &amp;another_student)'],['../class_student.html#a8522036f9f45eba735dc52d96021b738',1,'Student::Student(QString first, QString second, QString age, QString email, QString mobile, double grade)']]],
  ['students_14',['students',['../class_dashboard.html#aad78cd4c9ad1b30436ef175c214a8a6b',1,'Dashboard']]]
];
