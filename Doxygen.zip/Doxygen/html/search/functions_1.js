var searchData=
[
  ['class_0',['Class',['../class_class.html#a05c81356b40dca1b966f64257fbb17c8',1,'Class::Class(QObject *parent=nullptr)'],['../class_class.html#a7cc1db75cf9d5cec04467ca8be03928b',1,'Class::Class(QString name, QString code, Hall hall, QString time)'],['../class_class.html#a3f7d18500ae2ad39b520d792647524ed',1,'Class::Class(const Class &amp;another_class)']]],
  ['concatenate_5ftime_1',['concatenate_time',['../class_class.html#aa45cd9849565a841dfbbb3fffa817ba6',1,'Class']]]
];
