var searchData=
[
  ['dashboard_0',['Dashboard',['../class_dashboard.html',1,'']]]
];
