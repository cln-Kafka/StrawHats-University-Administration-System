var searchData=
[
  ['halls_0',['halls',['../class_dashboard.html#a2b53ba18f098c31553f2bc57def014c7',1,'Dashboard']]]
];
