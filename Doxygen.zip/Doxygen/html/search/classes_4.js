var searchData=
[
  ['person_0',['Person',['../class_person.html',1,'']]],
  ['professor_1',['Professor',['../class_professor.html',1,'']]]
];
